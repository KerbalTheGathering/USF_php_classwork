<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
	<title>Musical Scale</title>
</head>
<body>
	<?php
		$MusicalScale = array("do", "re", "mi", "fa", "so", "la", "ti");
		$OutputString = "The notes of the musical scale are: ";
		foreach ($MusicalScale as $CurrentNote)
			$OutputString .= " " . $CurrentNote;
		echo "<p>$OutputString</p>";
	?>
</body>
</html>