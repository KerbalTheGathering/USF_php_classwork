<!--
	Garrett Bloome
	U93205252
	12/6/2018
-->

<!DOCTYPE html>
<html>
<head>
	<title>What do you know about the Chinese zodiac signs?</title>
</head>
<body>
	<h1>What do you know about the Chinese zodiac signs?</h1>
	<?php
		//Answers are graded based on this array
		$answerKey = array('FALSE',
						'FALSE',
						'Rooster',
						'12',
						'Rat',
						'TRUE',
						'Seahorse',
						'Snake',
						'Dragon',
						'Pig');

		//Displays the form or graded quiz depending on data passed.
		function displayForm($data, $isGraded, $wrong){
			$AnsArray = $data['answers'];
			?>
			
			<form action="Project2.php" method="POST">
				<?php
				global $answerKey;
				if(!$isGraded) {
					?>
					<label for='name'>Your Name: </label>
					<input type='text' name='name' id='name' value="<?php if(isset($data['name']))echo $data['name']; else echo ""; ?>"><br />
					<label for='emailAddress'>Your Email Address: </label>
					<input type='email' name='emailAddress' id='emailAddress' value="<?php if(isset($data['emailAddress']))echo $data['emailAddress']; else echo ""; ?>"><br />
					<p>Your name and email address are required</p><br /><br />
					<p>You must answer all 10 questions before the quiz will be graded.</p>
					<?php
				}
				?>

				<p>1) The Chinese zodiac associates a sign with each month.<p/>
				<?php if(!$isGraded){
					if($AnsArray[0] == 'TRUE') $sel = " CHECKED"; else $sel = ""; ?>
					True<input type='radio' name="answers[1]" value="TRUE" <?php echo $sel ?>>
					<?php if($AnsArray[0] == 'FALSE') $sel = " CHECKED"; else $sel = ""; ?>
					False<input type='radio' name="answers[1]" value="FALSE" <?php echo $sel ?>>
					<?php
				} else {
					gradedAnswer($AnsArray[1], $answerKey[0]);
				}?>
				
				<p>2) The Chinese zodiac signs each have an equivalent constellations, like those of the occidental zodiac.</p>
				<?php if(!$isGraded){
					if($AnsArray[2] == 'TRUE') $sel = " CHECKED"; else $sel = ""; ?>
					True<input type='radio' name="answers[2]" value="TRUE" <?php echo $sel ?>>
					<?php if($AnsArray[2] == 'FALSE') $sel = " CHECKED"; else $sel = ""; ?>
					False<input type='radio' name="answers[2]" value="FALSE" <?php echo $sel ?>>
					<?php
				} else {
					gradedAnswer($AnsArray[2], $answerKey[1]);
				}?>

				
				<p>3) Which is the only bird that is a sign in the Chinese zodiac?</p>
				<?php if(!$isGraded){
					?>
					<label for='qThree'>Enter your response here: </label>
					<input type='text' name="answers[3]" id="qThree" value="<?php echo $AnsArray[3]; ?>">
					<?php
				} else {
					gradedAnswer($AnsArray[3], $answerKey[2]);
				}?>

				
				<p>4) How many signs are in the Chinese zodiac?</p>
				<?php if(!$isGraded){
					?>
					<label for='qFour'>Enter your response here: </label>
					<input type='text' name="answers[4]" id="qFour" value="<?php echo $AnsArray[4]; ?>">
					<?php
				} else {
					gradedAnswer($AnsArray[4], $answerKey[3]);
				}?>

				<p>5) The Chinese zodiac traditionally begins with which sign?</p>
				<?php if(!$isGraded){
					?>
					<select name="answers[5]">
					<option <?php if($AnsArray[5]=="-- Select the correct answer --") echo 'selected="selected"'; ?>>-- Select the correct answer --</option>
					<option <?php if($AnsArray[5]=="Rat") echo 'selected="selected"'; ?>>Rat</option>
					<option <?php if($AnsArray[5]=="Rabbit") echo 'selected="selected"'; ?>>Rabbit</option>
					<option <?php if($AnsArray[5]=="Snake") echo 'selected="selected"'; ?>>Snake</option>
					<option <?php if($AnsArray[5]=="Dog") echo 'selected="selected"'; ?>>Dog</option>
				</select>
					<?php
				} else {
					gradedAnswer($AnsArray[5], $answerKey[4]);
				}?>

				
				<p>6) Chinese zodiac signs represent different types of personalities</p>
				<?php if(!$isGraded){
					if($AnsArray[6] == 'TRUE') $sel = " CHECKED"; else $sel = ""; ?>
					True<input type='radio' name="answers[6]" value="TRUE" <?php echo $sel ?>>
					<?php if($AnsArray[6] == 'FALSE') $sel = " CHECKED"; else $sel = ""; ?>
					False<input type='radio' name="answers[6]" value="FALSE" <?php echo $sel ?>>
					<?php
				} else {
					gradedAnswer($AnsArray[6], $answerKey[5]);
				}?>

				
				<p>7) Which sign is not part of the Chinese zodiac?</p>
				<?php if(!$isGraded){
					?>
					<select name="answers[7]">
					<option <?php if($AnsArray[7]=="-- Select the correct answer --") echo 'selected="selected"'; ?>>-- Select the correct answer --</option>
					<option <?php if($AnsArray[7]=="Seahorse") echo 'selected="selected"'; ?>>Seahorse</option>
					<option <?php if($AnsArray[7]=="Snake") echo 'selected="selected"'; ?>>Snake</option>
					<option <?php if($AnsArray[7]=="Goat") echo 'selected="selected"'; ?>>Goat</option>
					<option <?php if($AnsArray[7]=="Monkey") echo 'selected="selected"'; ?>>Monkey</option>
				</select>
					<?php
				} else {
					gradedAnswer($AnsArray[7], $answerKey[6]);
				}?>

				<p>8) Which is the only reptile that is a sign in the Chinese zodiac?</p>
				<?php if(!$isGraded){
					?>
					<label for='qEight'>Enter your response here: </label>
					<input type='text' name="answers[8]" id="qEight" value="<?php echo $AnsArray[8]; ?>">
					<?php
				} else {
					gradedAnswer($AnsArray[8], $answerKey[7]);
				}?>

				
				<p>9) Which is the only imaginary animal that is a sign in the Chinese zodiac?</p>
				<?php if(!$isGraded){
					?>
					<label for='qNine'>Enter your response here: </label>
					<input type='text' name="answers[9]" id="qNine" value="<?php echo $AnsArray[9]; ?>">
					<?php
				} else {
					gradedAnswer($AnsArray[9], $answerKey[8]);
				}?>

				<p>10) The Chinese zodiac traditionally ends with which sign?</p>
				<?php if(!$isGraded){
					?>
					<select name="answers[10]">
						<option <?php if($AnsArray[10]=="-- Select the correct answer --") echo 'selected="selected"'; ?>>-- Select the correct answer --</option>
						<option <?php if($AnsArray[10]=="Pig") echo 'selected="selected"'; ?>>Pig</option>
						<option <?php if($AnsArray[10]=="Horse") echo 'selected="selected"'; ?>>Horse</option>
						<option <?php if($AnsArray[10]=="Monkey") echo 'selected="selected"'; ?>>Monkey</option>
						<option <?php if($AnsArray[10]=="-Rooster") echo 'selected="selected"'; ?>>Rooster</option>
					</select>
					<?php
				} else {
					gradedAnswer($AnsArray[10], $answerKey[9]);
				}?>

				<?php if (!$isGraded){
					?>
					<br /><br />
					<input type="reset" name="reset" value="Clear Quiz" />&nbsp;&nbsp;
					<input type="submit" name="submit" value="Grade Quiz" />
					<?php
				} else {
					?>
					<br />
					<?php
					gradeReport($wrong);
				} ?>
				
			</form>
			<?php
		}

		//Give user a message if they forgot to answer a question.
		function displayRequired($requiredField){
			if($requiredField == 'name' || $requiredField == 'emailAddress')
				echo "You did not enter your $requiredField.<br />\n";
			else
				echo "You did not answer \"$requiredField\".<br />\n";
		}

		//Check if field has been answered and format any strings.
		function validateInput($data, $fieldName){
			global $errorCount;
			if($fieldName == 'name' || $fieldName == 'emailAddress'){
				if(empty($data)){
					displayRequired($fieldName);
					$retval = "$fieldName";	
				} else {
					$retval = NULL;
				}
			}
			else if(empty($data) || !isset($data) || $data == '' || $data == "-- Select the correct answer --"){
				displayRequired($fieldName);
				++$errorCount;
				$retval = "$fieldName";
			} else {
				$retval = trim($data);
				$retval = stripslashes($data);
			}
			return($retval);
		}

		//Grades the entire quiz and returns the number of incorrect answers.
		function gradeQuiz ($data){
			$wrongAnswers = 0;
			$Index = 0;
			global $answerKey;
			foreach($data as $answer){
				if (strcasecmp($answer, $answerKey[$Index]) != 0){
					++$wrongAnswers;
				}
				++$Index;
			}
			return ($wrongAnswers);
		}

		//Displays the result of answered question.
		function gradedAnswer ($userAnswer, $storedAnswer) {
			if (strcasecmp($userAnswer, $storedAnswer) == 0) {
				echo "<p>&nbsp;&nbsp;<font color='green'>&#10004;</font> Your Answer, \"" .
					$userAnswer . "\" is correct</p>\n";
			}
			else {
				echo "<p>&nbsp;&nbsp;<font color='red'>&#10008;</font> Your Answer, \"" .
					$userAnswer . "\" is incorrect. The correct answer is " .
					$storedAnswer . ".</p>\n";
			}
		}

		//Reports to the user their final score and provides them with a message.
		function gradeReport ($missed) {
			$correctAnswers = 10 - $missed;
			$percentage = ($correctAnswers / 10) * 100;
			echo "<h3><strong>You answered " . $correctAnswers . " questions correctly. Final score is: " . $percentage . "%<br />";
			reportMessage($correctAnswers);
			echo "</strong></h3>";
		}

		//Pick which message to give the user based on number of correct answers and print.
		function reportMessage ($correct) {
			if ($correct == 0)	echo "You missed every question!";
			else if ($correct > 0 and $correct <= 2) echo "You really need to study the Chinese Zodiac";
			else if ($correct > 2 and $correct <= 5) echo "You know some things about the Chinese zodiac";
			else if ($correct > 5 and $correct <= 7) echo "You've done some research on the Chinese zodiac";
			else if ($correct > 7 and $correct <= 9) echo "You really know your Chinese Zodiac signs";
			else if ($correct == 10) echo "You are a Chinese Zodiac Expert";
		}

		/*
		This is the main thread
		*/
		if(isset($_POST['submit'])){
			$errorCount = 0;
			$graded = FALSE;
			$numberWrong = 0;

			$fullName = validateInput($_POST['name'], "name");
			$email = validateInput($_POST['emailAddress'], "emailAddress");
			if(is_array($_POST['answers'])) {
				$Answers = $_POST['answers'];
				if(is_array($Answers)){
					echo "<p>";
					$Index = 0;
					foreach ($Answers as $Answer){
						++$Index;
						
						$errorArray[] = validateInput($Answer, "Question " . $Index);
						
					}
					echo "</p><br />";
					if($errorCount>0){
						echo "<p>You left " . $errorCount . " questions blank. All 10 questions must be answered before the quiz is graded.</p><br />\n";
					} else {
						$numberWrong = gradeQuiz($Answers);
						$graded = TRUE;
					}
				}
			}
			displayForm($_POST, $graded, $numberWrong);
		}
		else{
			displayForm(NULL, NULL, NULL);
		}
	?>
</body>
</html>