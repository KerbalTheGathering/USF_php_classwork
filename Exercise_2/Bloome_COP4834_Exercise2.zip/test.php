<!DOCTYPE html>
<html>

<body>
	<h1>My first PFP page</h1>

	<?php
		echo "Hello World!";
	?>
</body>
</html>