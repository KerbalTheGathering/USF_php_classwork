<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
	<title>Display Numbers</title>
</head>
<body>
	<?php
		$IntegerVar = 150;
		$FloatingPointVar = 3.0e7; //	floating-point
								   //	number 30000000
		echo "<p>Integer variable: $IntegerVar<br />";
		echo "Floating-point variable: $FloatingPointVar</p>";
	?>
</body>
</html>